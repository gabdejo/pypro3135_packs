
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.7.0'
version = '1.7.0'
full_version = '1.7.0'
git_revision = 'a1f3385'
commit_count = '0'
release = True
if not release:
    version = full_version
